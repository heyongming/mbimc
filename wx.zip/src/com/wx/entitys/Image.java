package com.wx.entitys;

public class Image {
	private String MediaId;

	public String getMediaId() {
		return MediaId;
	}

	public void setMediaId(String mediaId) {
		MediaId = mediaId;
	}

	public Image() {
		super();
	}

	public Image(String mediaId) {
		super();
		MediaId = mediaId;
	}
}
