package com.wx.entitys.btn;

public class ClickButton extends Button {
	

	private String key;

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	
	public ClickButton() {
		super();
	}

}
