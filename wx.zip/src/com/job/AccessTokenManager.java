package com.job;

import com.alibaba.fastjson.JSONObject;
import com.util.HttpClientUtil;

public class AccessTokenManager {
	public static final String APPID = "wx1c2dbcd95b0928f5";
	public static final String AppSecret = "bc97d82fe8918e02c911f253929c8fa4";
	public static String Access_Token = "u83_dr3u49G_6MBldf9IMD239ds_89YFbnCZ2v4102tPDgFtartvLsL6nmKgPC4_8hrgXTEh8Cxe_e-g3WI457KyyAvsnPdWyawa_04AU0kT0qSRUAinVNdTv4q2khdUBJSaAJAGOX";


	public void execute() {
	/*	String url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=APPID&secret=APPSECRET";
		url = url.replace("APPID", AccessTokenManager.APPID);
		url = url.replace("APPSECRET", AccessTokenManager.AppSecret);
		String json = HttpClientUtil.httpGet(url);
		AccessToken accessToken = JSONObject.parseObject(json, AccessToken.class);
		Access_Token = accessToken.getAccess_token();
	*/
	}
}
